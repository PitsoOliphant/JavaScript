let express=require('express');
let customerRouter=express.Router();
//we need the model instance for the flow of data 
let CustomerModel=require('../models/Customer_Models');
//const { Module } = require('module');

customerRouter.get('/',async(req,res)=>
{
    let fetchedCustomers= await CustomerModel.find().where()
   
   
    res.json({fetchedCustomers})
});
customerRouter.post('/',async(req,res)=>
{
 let customer=
 {
    name:req.body.name,
    surname:req.body.surname
   
 }   

 let CustomerSave=new CustomerModel(customer);
 await CustomerSave.save()

 res.json("saved")
});
customerRouter.delete('/',async(req,res)=>
{
    CustomerModel.$where("name","Pitso")
    await CustomerModel.deleteMany()
    res.json("Deleted")
    
});
customerRouter.patch('/',async(req,res)=>
{
    let UpdatedCustomers={name:req.body.name,surname:req.body.surname};
    await CustomerModel.findByIdAndUpdate("638f0200ae0257c8e0dcca3d",UpdatedCustomers)
  
    res.json({message:"Updated!"})

});

module.exports=customerRouter;

