const express = require("express");
const app = express();
require("dotenv").config();
const mongoose = require("mongoose");
let host = process.env.HOST;
let port = process.env.PORT;
let db_path = process.env.DB_PATH;
mongoose.connect(db_path);
let DBconnection = mongoose.connection;
let CustomerModel=require('./models/Customer_Models')
DBconnection.on("erro", (err) => {
  console.log(`Error: ${err}`);
});
DBconnection.on("open", () => {
  console.log(`connected`);
});

//Importing customer from Routes into CustomerRoutes
let CustomerRouter = require("./Routes/customer");

app.use(express.json());
app.use("/customer", CustomerRouter);

app.listen(port, () => {
  console.log(`server is running on http://${host}:${port}`);
});
