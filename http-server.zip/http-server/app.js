

const http =require('http');
const fs = require('fs').promises
const host='localhost';
const port=8080;
const RequestListener =function (request,response) 
{
    switch (request.url)
     {
        case "/":
            fs.readFile(__dirname+"/index.html")
    .then( contents=>
    {
        response.setHeader("Content-Type","text/html")
        response.writeHead(200);
        response.end(contents)
    })
            
            break;
    
        case"/about":
        fs.readFile(__dirname+"/about.html")
    .then( contents=>
    {
        response.setHeader("Content-Type","text/html")
        response.writeHead(200);
        response.end(contents)
    })
            break;
            case "/contact":
                fs.readFile(__dirname+"/contact.html")
    .then( contents=>
    {
        response.setHeader("Content-Type","text/html")
        response.writeHead(200);
        response.end(contents)
    })
    break;
    

    }
   
}

const server =http.createServer(RequestListener);


server.listen(port,host,()=>
{
    console.log(`${host}:${port}`);
})



