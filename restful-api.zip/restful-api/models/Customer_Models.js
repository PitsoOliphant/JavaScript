let mongoose = require("mongoose"); //import mongoose, to translate
let customer = {
  name: { type: String, required: true },
  surname: { type: String, required: true }
};

let customerSchema = new mongoose.Schema(customer); //Enables mongoose to understand and interprets the structure to the language the database understands
module.exports = mongoose.model("CustomerModels", customerSchema);
