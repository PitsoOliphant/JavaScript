const { response } = require('express');
const express =require('express');
const { request } = require('http');
require('dotenv').config()
const server =express();
const port =8000;
const host='localhost';
let database=[]
let lastName=[]
server.set('view engine','ejs')
server.use(express.static('public'))
server.use(express.urlencoded())
server.get('/',(request,response)=>
{
    response.render('index')
})

server.get('/contact',(request,response)=>
{
    response.render('contact')
})

server.get('/about',(request,response)=>
{
    response.render('about')
})

server.get('/form',(request,response)=>
{
    response.render('form')
})

server.post('/reading',(request,response)=>
{
   let name=request.body.FirstName;
   let surname=request.body.LasName;
   let age=request.body.EnterAge;
  
let data=
{
    name:name,
    surname:surname,
    age:age
}


database.push(data)

console.log(database);
response.send(database)


})

server.get('/tloubatla',(request,response)=>
{
    lastName=data.filter(user=>user.surname==='Tloubatla')
response.render('tloubatla',lastName)

})

server.listen(port,host,()=>
{
    console.log(`server is is operating on http://${host}:${port}`);
})